#!/bin/bash
cat employees.sql <(echo '') load_departments.dump <(echo '') load_employees.dump <(echo '') load_dept_emp.dump \
    load_dept_manager.dump <(echo '') load_titles.dump <(echo '') load_salaries.dump \
    | sed 's/`/"/g' > employees.postgresql.sql

